# Laço de repetição - for in
for i in range(10):
    print(i)

print('Começando do 1')
for i in range(1, 10):
    print(i)

# Incrementando 2
print("Incrementando 2")
for i in range(1, 10, +2):
    print(i)

print("Decrementando")
for i in range(10, 0, -1):
    print(i)
print('Olá Mundo')
print("Ola Mundo :) ")
print('E ele disse: "Ola Mundo" ')
print("it's  mario")
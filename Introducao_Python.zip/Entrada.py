# Receber uma entrada - input
print("---------Formulário------------")
nome = input("Qual o seu nome? ")
idade = int(input("Qual a sua idade? "))
peso = float(input("Qual o seu peso? "))
feliz = bool(input("Você é feliz? "))

print('Seu nome é: ' + nome)
print('Sua idade é: ', idade)
print(nome)
print(idade)
print(peso)
print(feliz)

idade10 = idade + 10
print('Daqui a 10 anos, sua idade vai ser: ', idade10)
# Tipos de Váriaveis - Int - Float - Bool  - String
nome = 'Anderson'
idade= 20
peso = 75.80
feliz= True

print(nome)
print(idade)
print(peso)
print(feliz)

print(type(nome))
print(type(idade))
print(type(peso))
print(type(feliz))
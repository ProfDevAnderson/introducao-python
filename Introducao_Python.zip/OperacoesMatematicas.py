# Operações Matemática

num1 = int(input('Digite o numero 1: '))
num2 = int(input('Digite o numero 2: '))

print('Soma: ', num1+num2)
print('Subtração: ', num1-num2)
print('Multiplicação: ', num1*num2)
print('Divisao: ', num1/num2)
print('Exponenciação : ', num1**num2)
print('Resto : ', num1%num2)